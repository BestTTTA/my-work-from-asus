package runner

const (
	//PlatformWindows const for windows
	PlatformWindows = "windows"
)
