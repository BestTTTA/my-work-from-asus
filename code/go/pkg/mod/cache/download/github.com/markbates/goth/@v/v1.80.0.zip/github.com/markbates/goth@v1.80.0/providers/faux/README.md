# FauxProvider

This provider is merely here to help with testing other parts of these packages. I wouldn't recommend using it. :)
