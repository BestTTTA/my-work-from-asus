# Semconv

[![PkgGoDev](https://pkg.go.dev/badge/go.opentelemetry.io/otel/semconv)](https://pkg.go.dev/go.opentelemetry.io/otel/semconv)
