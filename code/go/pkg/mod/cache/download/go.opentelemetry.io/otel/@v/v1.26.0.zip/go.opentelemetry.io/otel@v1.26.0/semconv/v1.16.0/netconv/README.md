# Semconv v1.16.0 NET conv

[![PkgGoDev](https://pkg.go.dev/badge/go.opentelemetry.io/otel/semconv/v1.16.0/netconv)](https://pkg.go.dev/go.opentelemetry.io/otel/semconv/v1.16.0/netconv)
